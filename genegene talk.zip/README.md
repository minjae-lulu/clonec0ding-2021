#kakao clone 2021 

practice HTML & CSS 